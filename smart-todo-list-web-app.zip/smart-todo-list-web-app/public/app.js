const taskForm = document.getElementById("taskForm");
const taskTitle = document.getElementById("taskTitle");
const priorityInput = document.getElementById("priority");
const dueDateInput = document.getElementById("dueDate");
const taskList = document.getElementById("taskList");
const filterTasks = document.getElementById("filterTasks");
const formMessage = document.getElementById("formMessage");

let tasks = [];

async function api(url, options = {}) {
  const response = await fetch(url, {
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    ...options
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.message || "Something went wrong.");
  return data;
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (char) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[char]);
}

function updateStats() {
  document.getElementById("totalCount").textContent = tasks.length;
  document.getElementById("activeCount").textContent = tasks.filter((task) => !task.completed).length;
  document.getElementById("completedCount").textContent = tasks.filter((task) => task.completed).length;
}

function renderTasks() {
  updateStats();
  const filter = filterTasks.value;
  const visibleTasks = tasks.filter((task) => {
    if (filter === "active") return !task.completed;
    if (filter === "completed") return task.completed;
    return true;
  });

  if (!visibleTasks.length) {
    const message = tasks.length ? "No tasks match this filter." : "Your list is clear. Add your first task above!";
    taskList.innerHTML = `<div class="empty-state"><span>✦</span><p>${message}</p></div>`;
    return;
  }

  taskList.innerHTML = visibleTasks.map((task) => {
    const safeTitle = escapeHtml(task.title);
    const safeId = escapeHtml(task._id);
    const priorityClass = task.priority.toLowerCase();
    const dueText = task.dueDate ? `Due ${escapeHtml(task.dueDate)}` : "No deadline";
    return `
      <article class="task-item ${task.completed ? "done" : ""}">
        <button class="check-button" data-action="toggle" data-id="${safeId}" aria-label="${task.completed ? "Mark as in progress" : "Mark as completed"}">${task.completed ? "✓" : ""}</button>
        <div class="task-content">
          <div class="task-title">${safeTitle}</div>
          <div class="task-meta">
            <span class="pill ${priorityClass}">${escapeHtml(task.priority)} priority</span>
            <span class="due-date">${dueText}</span>
          </div>
        </div>
        <div class="task-actions">
          <button class="icon-button" data-action="edit" data-id="${safeId}" aria-label="Edit ${safeTitle}">Edit</button>
          <button class="icon-button delete" data-action="delete" data-id="${safeId}" aria-label="Delete ${safeTitle}">Delete</button>
        </div>
      </article>`;
  }).join("");
}

async function loadTasks() {
  try {
    tasks = await api("/api/tasks");
    renderTasks();
  } catch (error) {
    taskList.innerHTML = `<div class="empty-state"><span>!</span><p>${escapeHtml(error.message)}</p></div>`;
  }
}

taskForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  formMessage.textContent = "";
  const title = taskTitle.value.trim();
  if (!title) {
    formMessage.textContent = "Please enter a task title.";
    return;
  }

  try {
    const task = await api("/api/tasks", {
      method: "POST",
      body: JSON.stringify({ title, priority: priorityInput.value, dueDate: dueDateInput.value })
    });
    tasks.unshift(task);
    taskForm.reset();
    priorityInput.value = "Medium";
    renderTasks();
    taskTitle.focus();
  } catch (error) {
    formMessage.textContent = error.message;
  }
});

taskList.addEventListener("click", async (event) => {
  const button = event.target.closest("button[data-action]");
  if (!button) return;
  const { action, id } = button.dataset;
  const task = tasks.find((item) => item._id === id);
  if (!task) return;

  try {
    if (action === "toggle") {
      const updated = await api(`/api/tasks/${encodeURIComponent(id)}`, {
        method: "PATCH",
        body: JSON.stringify({ completed: !task.completed })
      });
      tasks = tasks.map((item) => item._id === id ? updated : item);
    } else if (action === "delete") {
      if (!confirm(`Delete "${task.title}"?`)) return;
      await api(`/api/tasks/${encodeURIComponent(id)}`, { method: "DELETE" });
      tasks = tasks.filter((item) => item._id !== id);
    } else if (action === "edit") {
      const title = prompt("Edit task title:", task.title);
      if (title === null) return;
      if (!title.trim()) {
        alert("Task title cannot be empty.");
        return;
      }
      const updated = await api(`/api/tasks/${encodeURIComponent(id)}`, {
        method: "PATCH",
        body: JSON.stringify({ title: title.trim() })
      });
      tasks = tasks.map((item) => item._id === id ? updated : item);
    }
    renderTasks();
  } catch (error) {
    alert(error.message);
  }
});

filterTasks.addEventListener("change", renderTasks);
loadTasks();