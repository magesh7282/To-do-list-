# Smart To-Do List Web Application

A responsive full-stack task manager built with HTML, CSS, JavaScript, Node.js, Express, and MongoDB.

## Features

- Create, edit, and delete tasks
- Mark tasks as completed or in progress
- Choose Low, Medium, or High priority
- Add optional due dates
- Filter all, active, and completed tasks
- Summary cards for total, active, and completed tasks
- Responsive mobile and desktop layout
- MongoDB persistence when configured
- Temporary in-memory fallback so the app can be tested without MongoDB

## Requirements

- Node.js (LTS recommended)
- npm
- Optional: MongoDB local server or a MongoDB Atlas connection string

## Run locally

1. Extract this project ZIP and open the `smart-todo-list-web-app` folder in VS Code.
2. Open a terminal in that folder.
3. Install dependencies:

   ```bash
   npm install
   ```

4. Copy `.env.example` to a new file named `.env`.
5. To use MongoDB, replace the placeholder `MONGODB_URI` value in `.env` with your own connection string. For example, local MongoDB can use:

   ```env
   MONGODB_URI=mongodb://127.0.0.1:27017/smart_todo
   PORT=3000
   ```

   If MongoDB is not configured, the app runs with temporary in-memory storage. Tasks in that mode are cleared when the server restarts.

6. Start the server:

   ```bash
   npm start
   ```

7. Open `http://localhost:3000` in your browser.

## Project structure

```text
smart-todo-list-web-app/
├── public/
│   ├── index.html
│   ├── style.css
│   └── app.js
├── .env.example
├── .gitignore
├── package.json
├── README.md
└── server.js
```

## Upload to GitHub

1. Create a new repository on GitHub.
2. Keep `.env` private; do not upload credentials or connection strings.
3. Upload the project files, or run these commands in the project folder after creating an empty repository:

   ```bash
   git init
   git add .
   git commit -m "Add Smart To-Do List project"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
   git push -u origin main
   ```

Replace the example GitHub URL with your own repository URL.

## Note

This is a student starter project. Review, test, and understand the code before submitting it. If using MongoDB Atlas, allow network access only as appropriate and never commit database credentials.
