const express = require("express");
const mongoose = require("mongoose");
const path = require("path");
require("dotenv").config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const taskSchema = new mongoose.Schema(
  {
    title: { type: String, required: true, trim: true, maxlength: 200 },
    priority: { type: String, enum: ["Low", "Medium", "High"], default: "Medium" },
    dueDate: { type: String, default: "" },
    completed: { type: Boolean, default: false }
  },
  { timestamps: true }
);

const Task = mongoose.model("Task", taskSchema);

// In-memory fallback keeps the app usable before MongoDB is configured.
// Tasks are temporary in fallback mode and reset when the server restarts.
let memoryTasks = [];
let mongoReady = false;

function makeId() {
  return `${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

app.get("/api/tasks", async (req, res) => {
  try {
    if (mongoReady) {
      const tasks = await Task.find().sort({ createdAt: -1 });
      return res.json(tasks);
    }
    return res.json(memoryTasks);
  } catch (error) {
    return res.status(500).json({ message: "Could not load tasks." });
  }
});

app.post("/api/tasks", async (req, res) => {
  const title = String(req.body.title || "").trim();
  const priority = ["Low", "Medium", "High"].includes(req.body.priority) ? req.body.priority : "Medium";
  const dueDate = String(req.body.dueDate || "");

  if (!title) return res.status(400).json({ message: "Please enter a task title." });
  if (title.length > 200) return res.status(400).json({ message: "Task title must be 200 characters or fewer." });

  try {
    if (mongoReady) {
      const task = await Task.create({ title, priority, dueDate });
      return res.status(201).json(task);
    }
    const task = { _id: makeId(), title, priority, dueDate, completed: false, createdAt: new Date().toISOString() };
    memoryTasks.unshift(task);
    return res.status(201).json(task);
  } catch (error) {
    return res.status(500).json({ message: "Could not create task." });
  }
});

app.patch("/api/tasks/:id", async (req, res) => {
  try {
    if (mongoReady) {
      const task = await Task.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
      if (!task) return res.status(404).json({ message: "Task not found." });
      return res.json(task);
    }
    const index = memoryTasks.findIndex((task) => task._id === req.params.id);
    if (index === -1) return res.status(404).json({ message: "Task not found." });
    if (typeof req.body.completed === "boolean") memoryTasks[index].completed = req.body.completed;
    if (typeof req.body.title === "string" && req.body.title.trim()) memoryTasks[index].title = req.body.title.trim().slice(0, 200);
    if (["Low", "Medium", "High"].includes(req.body.priority)) memoryTasks[index].priority = req.body.priority;
    if (typeof req.body.dueDate === "string") memoryTasks[index].dueDate = req.body.dueDate;
    return res.json(memoryTasks[index]);
  } catch (error) {
    return res.status(400).json({ message: "Could not update task. Check the task ID and values." });
  }
});

app.delete("/api/tasks/:id", async (req, res) => {
  try {
    if (mongoReady) {
      const task = await Task.findByIdAndDelete(req.params.id);
      if (!task) return res.status(404).json({ message: "Task not found." });
      return res.json({ message: "Task deleted." });
    }
    const before = memoryTasks.length;
    memoryTasks = memoryTasks.filter((task) => task._id !== req.params.id);
    if (before === memoryTasks.length) return res.status(404).json({ message: "Task not found." });
    return res.json({ message: "Task deleted." });
  } catch (error) {
    return res.status(400).json({ message: "Could not delete task." });
  }
});

async function start() {
  const uri = process.env.MONGODB_URI;
  if (uri && !uri.includes("your_mongodb_connection_string_here")) {
    try {
      await mongoose.connect(uri);
      mongoReady = true;
      console.log("Connected to MongoDB.");
    } catch (error) {
      console.error("MongoDB connection failed. Starting with temporary in-memory storage.");
    }
  } else {
    console.log("MongoDB URI not configured. Starting with temporary in-memory storage.");
  }

  app.listen(PORT, () => {
    console.log(`Smart To-Do List running at http://localhost:${PORT}`);
  });
}

start();